// ─────────────────────────────────────────────────────────────
//  PORTFOLIO CONTENT — single source of truth.
//  Edit this file to update your site, then commit & push.
//  (Tip: the Admin.dc.html editor from the design phase exports
//   the same shape — paste its values here.)
// ─────────────────────────────────────────────────────────────

export interface Link { label: string; href: string; handle: string; }
export interface Metric { value: string; label: string; }
export interface TechStack { core?: string[]; infra?: string[]; automation?: string[]; }
export interface ProjectDetails { overview: string; challenge: string; implementation: string; outcome: string; }
export interface Project {
  title: string;
  year: string;
  role: string;
  blurb: string;
  metrics: Metric[];
  tech: TechStack;
  details?: ProjectDetails;
  href: string;
}
export interface Service { title: string; desc: string; }
export interface SkillGroup { group: string; items: string[]; }
export interface ExperienceItem { company: string; role: string; period: string; points: string[]; }
export interface EducationItem { school: string; degree: string; detail: string; period: string; }

export const profile = {
  name: "Mohamad Fajar Mahardika",
  role: "Cloud Infrastructure Engineer",
  tagline:
    "I run the OpenStack core platforms behind Indonesia's largest mobile networks: millions of subscribers, hundreds of gigabits of live traffic.",
  location: "South Jakarta, Indonesia. Open to remote or relocation",
  available: "Open to Cloud, DevOps, Platform and SRE roles",
  email: "mf.mahardika@gmail.com",
  phone: "+62 812-3252-2330",
  photo: "", // put a file in /public (e.g. /public/me.jpg) and set this to "/me.jpg"
  links: [
    { label: "GitHub", href: "https://github.com/fajarmhr", handle: "fajarmhr" },
    { label: "LinkedIn", href: "https://linkedin.com/in/massffajar", handle: "massffajar" },
  ] as Link[],
};

// Résumé is pulled LIVE from your CV Builder app (deployed on Vercel).
// Publish a résumé there, copy its share token, and paste both below.
// The portfolio shows an on-screen preview that always reflects the latest version.
export const resume = {
  appUrl: "https://your-cv-app.vercel.app", // your CV Builder base URL
  token: "",                                // the published résumé's share token
};

export const about: string[] = [
  "I'm a cloud infrastructure engineer at Huawei Indonesia, running the OpenStack platforms that carry the 4G and 5G core networks for the country's top three operators. This is work where reliability isn't optional: millions of subscribers and hundreds of gigabits of production traffic depend on it staying up.",
  "I'm happiest removing operational toil with Python health-checks, YAML-defined infrastructure, and the lifecycle management of virtualized and containerized network functions. I'm now looking for cloud platform, DevOps and SRE roles where that operational rigor is the whole job.",
];

// Each project leads with its IMPACT metrics, then grouped technology, then an
// optional expandable Challenge → Action → Result breakdown.
export const projects: Project[] = [
  {
    title: "Telkomsel 5G Core Migration",
    year: "2025-26",
    role: "PS Core Network Engineer",
    blurb:
      "Migrated international roaming traffic from Surabaya to Jakarta core sites with minimal service disruption, and commissioned the by.U APN with DPI across nationwide SMF and UPF platforms.",
    metrics: [
      { value: "Nationwide", label: "5G core scope" },
      { value: "SMF / UPF", label: "platforms cut over" },
      { value: "Minimal", label: "service disruption" },
    ],
    tech: {
      core: ["5G Core", "SMF", "UPF", "DPI"],
      infra: ["FusionSphere", "Linux"],
      automation: ["Python"],
    },
    details: {
      overview:
        "Consolidation of Telkomsel's packet-switched core: relocating international roaming onto Jakarta core sites while extending nationwide 5G SMF/UPF coverage.",
      challenge:
        "International roaming is unforgiving of downtime: the cutover from Surabaya to Jakarta had to preserve live sessions and signalling for partner networks.",
      implementation:
        "Led the relocation of roaming traffic across core sites and commissioned the by.U APN with deep packet inspection across the nationwide SMF and UPF platforms.",
      outcome:
        "Roaming relocated with minimal service disruption; by.U gained APN-level policy control and DPI visibility across the national 5G core.",
    },
    href: "#",
  },
  {
    title: "Indosat Ooredoo Hutchison",
    year: "2024-26",
    role: "PS Core Network Engineer",
    blurb:
      "Planned and executed 4G CUPS and 5G UPF/SMF capacity expansions across Sumatra and Kalimantan, and stood up a private LTE core (MME, SPGW-C/U, HSS) for an enterprise client.",
    metrics: [
      { value: "4.5M+", label: "subscribers" },
      { value: "360+", label: "Gbps capacity" },
      { value: "Private LTE", label: "enterprise core" },
    ],
    tech: {
      core: ["4G CUPS", "5G UPF", "SMF", "MME", "SPGW-C/U", "HSS"],
      infra: ["OpenStack", "FusionSphere", "VNF"],
      automation: ["Python", "YAML"],
    },
    details: {
      overview:
        "A multi-region capacity program across Indosat's 4G and 5G packet core, plus a dedicated private LTE core for an enterprise customer.",
      challenge:
        "Expanding live CUPS and UPF/SMF capacity in Sumatra and Kalimantan without impacting the 4.5M+ subscribers already on the platform, while standing up an isolated enterprise core in parallel.",
      implementation:
        "Planned and executed 4G CUPS and 5G UPF/SMF capacity expansions, and commissioned a private LTE core (MME, SPGW-C/U and HSS) for enterprise services.",
      outcome:
        "Added 360+ Gbps of headroom across two regions and delivered a production private LTE core for enterprise connectivity.",
    },
    href: "#",
  },
  {
    title: "XL Axiata Jakarta Packet Core",
    year: "2023-24",
    role: "PS Core Network Engineer",
    blurb:
      "Installed, commissioned and cut over the 4G CUPS packet core for the Jakarta region, and migrated MME services for North Sumatra, both serving 10M+ subscribers.",
    metrics: [
      { value: "10M+", label: "subscribers" },
      { value: "200+", label: "Gbps capacity" },
      { value: "2", label: "regions migrated" },
    ],
    tech: {
      core: ["4G CUPS", "MME", "Packet Core"],
      infra: ["FusionSphere", "Linux"],
      automation: ["Python", "YAML"],
    },
    details: {
      overview:
        "A greenfield 4G CUPS packet core for the Jakarta region, paired with an MME service migration for North Sumatra.",
      challenge:
        "Bringing a new packet core into service and migrating MME for regions collectively serving 10M+ subscribers demanded careful commissioning and cutover sequencing.",
      implementation:
        "Installed, commissioned and cut over the Jakarta 4G CUPS packet core, then migrated North Sumatra MME services onto the platform.",
      outcome:
        "Two regions serving 10M+ subscribers carried on the new core, with 200+ Gbps of capacity running in production.",
    },
    href: "#",
  },
  {
    title: "Open-Source 5G Core Research",
    year: "2023",
    role: "Mobile Core Analyst",
    blurb:
      "Built and analyzed an open-source 5G core, tracing subscriber registration across AMF, SMF and UPF, the basis for a Sinta-2 indexed journal publication.",
    metrics: [
      { value: "Sinta-2", label: "indexed publication" },
      { value: "5G SA", label: "registration analysis" },
      { value: "Open5GS", label: "AMF / SMF / UPF" },
    ],
    tech: {
      core: ["5G Core", "AMF / SMF / UPF"],
      infra: ["Open5GS", "Linux", "Containers"],
      automation: ["Python"],
    },
    details: {
      overview: "A hands-on study of 5G standalone core internals using an open-source stack.",
      challenge:
        "Understanding and validating the 5G registration procedure end-to-end across AMF, SMF and UPF without vendor tooling.",
      implementation:
        "Built an open-source 5G core (Open5GS) and traced the subscriber registration flow across the AMF, SMF and UPF.",
      outcome: "Findings formed the basis of a Sinta-2 indexed journal publication.",
    },
    href: "#",
  },
];

export const services: Service[] = [
  { title: "Cloud Platform Operations", desc: "Running OpenStack and virtualized infrastructure that stays available under real production load." },
  { title: "Automation & IaC", desc: "Replacing operational toil with Python and YAML-defined, repeatable infrastructure." },
  { title: "Reliability at Scale", desc: "Capacity planning, lifecycle management and zero-disruption migrations for systems serving millions." },
];

export const skills: SkillGroup[] = [
  { group: "Cloud & Virtualization", items: ["OpenStack", "Huawei FusionSphere", "VNF / CNF", "KVM"] },
  { group: "Automation & IaC", items: ["Python", "YAML", "Bash", "Infrastructure as Code"] },
  { group: "Platform & Linux", items: ["Linux Administration", "Containers", "Compute & Storage", "Networking"] },
  { group: "Telecom Core", items: ["4G CUPS", "5G Core (AMF/SMF/UPF)", "MME", "Packet Core"] },
];

export const experience: ExperienceItem[] = [
  {
    company: "Huawei Indonesia",
    role: "Intermediate Cloud Core Engineer",
    period: "Jun 2023 - Present",
    points: [
      "Operate large-scale OpenStack (Huawei FusionSphere) infrastructure carrying mission-critical telecom core services at national scale.",
      "Build Python automation for infrastructure health checks, monitoring validation and operational reporting across cloud, server and storage.",
      "Lead deployment, upgrade and capacity expansion of 4G/5G core workloads on VMs and containers, across multi-vendor teams.",
    ],
  },
  {
    company: "Basic & Applied Research, Telkom University",
    role: "Mobile Core Analyst",
    period: "Mar 2023",
    points: [
      "Analyzed 5G Core network functions (AMF, SMF, UPF), tracing the subscriber registration flow for a Sinta-2 journal publication.",
    ],
  },
];

export const education: EducationItem[] = [
  { school: "Telkom University", degree: "B.Tech, Telecommunication Engineering", detail: "GPA 3.32", period: "2023" },
];

export const languages: string[] = ["Indonesian (Native)", "English (Advanced)"];
